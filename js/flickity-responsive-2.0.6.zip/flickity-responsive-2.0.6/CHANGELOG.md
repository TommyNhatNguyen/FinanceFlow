### v2.0.3 - 2023-01-13

- Validate wrapAround option

### v2.0.2 - 2022-11-18

- Fix bug detect first/last slide to disable prev/next button.

### v2.0.0 - 2022-11-11

- Refactor dev environment with webpack
- Support jQuery and vanilla JS
- Release NPM package

### v1.1.1 - 2021-09-27

- Fix bug when `responsive` property is not defined.

### v1.1.0 - 2021-09-24

- The core responsive handle has been split into `class ResponsiveObject()` so we can use this feature for other
  libraries as well.

> See [ResponsiveObject()](https://github.com/phucbm/js-gist/blob/main/responsive-object.js)

### v1.0.0 - 2021-08-14

- jQuery plugin for Flickity responsive